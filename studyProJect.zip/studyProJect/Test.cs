using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace projectstudy
{
    
    class Test
    {
        static void Main(string[] arg)
        {
            AsyncAwait.Caller();

            Console.Read();
        }
    }
}

